import numpy as np
import json

from qiskit import IBMQ, QuantumCircuit
from qiskit.providers.ibmq import RunnerResult

from qiskit import Aer
from qiskit.providers.ibmq.runtime import UserMessenger
from qiskit.providers.ibmq.runtime.utils import RuntimeEncoder, RuntimeDecoder

from qiskit import transpile


from qiskit.circuit import ParameterVector
from qiskit.aqua import QuantumInstance
from qiskit.aqua.operators import CircuitSampler, StateFn
from qiskit.aqua.operators.expectations import PauliExpectation

from pauli_function import *




def ei(i, n):
	vi = np.zeros(n)
	vi[i] = 1.0
	return vi[:]

def vqe_ansatz(p):
    n_spins = 3

    circuit = QuantumCircuit(n_spins)
    for i in range(n_spins):
	    circuit.h(i)

    count = 0
    for i in range(n_spins):
        circuit.rx(p[count], i)
        count += 1

    for i in range(n_spins-1):
        circuit.cnot(i, i+1)

    for i in range(n_spins):
        circuit.rx(p[count], i)
        count += 1

    return circuit
    

def main(backend, user_messenger, **kwargs):
    """Main entry point of the program.

    Args:
        backend: Backend to submit the circuits to.
        user_messenger: Used to communicate with the program consumer.
        kwargs: User inputs.
    """
    iterations = kwargs.pop('maxiter', 10)
    n_spins = 3
    shots = 100
    nparameters = 2*n_spins

    instance = QuantumInstance(backend=backend, shots=shots)
    sampler = CircuitSampler(instance)

    H = generate_ising(n_spins, -1, -1)

    empty_params = ParameterVector('ep', nparameters)
    ansatz = vqe_ansatz(empty_params)
    var_params = np.zeros(nparameters)
    
    expectation = PauliExpectation()

    H_prj = StateFn(H, is_measurement=True)
    state_wfn = H_prj @ StateFn(ansatz)
    state_wfn = expectation.convert(state_wfn)

    expectH = []

    for it in range(iterations):
        
        # build dictionary of parameters to values
        # {left[0]: parameters[0], .. ., right[0]: parameters[0] + shift[0], ...}

        # First create the dictionary for expectation value
        values_dict = [dict(zip(empty_params, var_params.tolist()))]

        # Then the values for the gradient
        for i in range(nparameters):
            values_dict.append(dict(zip(empty_params, (var_params + ei(i, nparameters)*np.pi/2.0).tolist())))
            values_dict.append(dict(zip(empty_params, (var_params - ei(i, nparameters)*np.pi/2.0).tolist())))

        results = []

        for values in values_dict:
            sampled_op = sampler.convert(state_wfn, params=values)

            mean = sampled_op.eval()[0].real
            est_err = 0

            if (not instance.is_statevector):
                variance = expectation.compute_variance(sampled_op)[0].real
                est_err = np.sqrt(variance/shots)

            results.append([mean, est_err])

        E = [0, 0]
        g = np.zeros((nparameters, 2))

        E[0], E[1] = results[0]
        expectH.append(E)

        for i in range(nparameters):
            rplus = results[1+2*i]
            rminus = results[2+2*i]
            g[i, :] = (rplus[0]-rminus[0])/2.0, np.sqrt(rplus[1]**2+rminus[1]**2)/2.0

        var_params -= 1e-3*g[:, 0]
    
    output = {"E": expectH[:][0], "E_err": expectH[:][1]}

    return output
